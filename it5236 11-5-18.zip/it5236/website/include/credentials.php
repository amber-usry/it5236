<?php

class Credentials {

    // Declare the credentials to the database
    public $servername = "mysqlforlambdatest.czx9deednziq.us-east-1.rds.amazonaws.com";
    public $serverusername = "LambdaTestUser";
    public $serverpassword = "Scissors&Ice*";
    public $serverdb = "it5236";

}

?>
